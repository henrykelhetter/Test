function main(){
    var tabPhoto= ['photo_000','photo_001','photo_002','photo_003','photo_004','photo_005','photo_006','photo_007','photo_008','photo_009'];
    var tabPhrase= ['Vive les vacances','HTML c\'est bien','CSS c\'est top','JS c\'est trop bien','JSON Bourne','Encore Encore','Ca fini quand ?'];
    var photo = tabPhoto[selectRamdom(tabPhoto.length)];
    var tabPhrase = tabPhrase[selectRamdom(tabPhrase.length)];
    
    document.write( "<figure><img src=\"Photo/"+ photo +".jpg\" id=\"hiddenImg\" height=\"300\" width=\"700\">");
    document.write( "<figcaption>"+ tabPhrase +"</figcaption></figure>");
}

function selectRamdom(tailleTab){
    var ind = (Math.floor(Math.random() * tailleTab));
    return ind;
}

